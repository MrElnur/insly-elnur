<style>
    .footer {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 100%;
        text-align: center;
    }
</style>
<div class="footer">
<div id="copyright text-right">© Copyright 2019 Elnur Mammadov</div>
</div>
