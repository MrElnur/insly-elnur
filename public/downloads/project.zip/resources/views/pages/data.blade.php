@extends('layouts.default')
@section('content')
    <div class="container">
        <img src="{{ asset('image/schema.png') }}" alt="schema">
        <button><a href="downloads/schema.sql">Download SQL File</a></button>
    </div>

@stop
