@extends('layouts.default')
@section('content')
    i am the home page

@stop
