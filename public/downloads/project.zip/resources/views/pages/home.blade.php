@extends('layouts.default')
@section('content')
    <h2 style="text-align: center">Please find the answers in navigation bar</h2>

@stop
