@extends('layouts.default')
@section('content')
    i am the about page
@stop
