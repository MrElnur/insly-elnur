@extends('layouts.default')
@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <button><a href="downloads/schema.sql">Download SQL File</a></button>
            </div>

        <div class="col-md-3">
            <button><a href="downloads/project.zip">Download Project zip</a></button><p>Laravel</p>
        </div>

        </div>
    </div>

@stop
